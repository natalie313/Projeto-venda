<?php
header('Content-Type: text/html; charset=utf-8');
//nome do produto, valor, quantidade e preço de venda
//variaveis
$nome = ($_POST["nome"]);
$valor = ($_POST["valor"]);
$qntd = ($_POST["quantidade"]);
$total =0;

//calculos
$total = $valor * $qntd;
if($total <= 20){
    $total = $total * (45 / 100);
    echo "O valor de venda é de: R$ " . $total;
    echo "Nome do produto: " . $nome;
    echo "Valor: R$" . $valor;
    echo "Quantidade: " . $qntd;

}else if ($total > 20){
    $total = $total * (30 / 100);
    echo "O valor de venda é de: R$ " . $total;
    echo "Nome do produto: " . $nome;
    echo "Valor: R$" . $valor;
    echo "Quantidade: " . $qntd;
}

?>